import React from "react";

function About() {
  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h2>About Us</h2>
      <p>This is a simple URL shortener React app for Lab 9.</p>
      <p>Created by Khalid for CPIT-405.</p>
    </div>
  );
}

export default About;
